@echo off
echo Building AntiESP-1.0.0.jar...
mvn clean package
if %errorlevel% neq 0 (
    echo Build failed! Make sure Java 21 and Maven are installed.
    pause
    exit /b %errorlevel%
)
echo Done! Copy target\AntiESP-1.0.0.jar into your server's plugins folder.
pause
